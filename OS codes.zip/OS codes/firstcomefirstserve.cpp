#include<bits/stdc++.h>
using namespace std;
struct item{
    int pid;
    int stime;
    int btime;
    int ctime;
    int tatime;
    int wtime;
};
static bool cmp(item a,item b){
    return a.stime<b.stime;
}
int main(){
    cout<<"Enter no of processes:"<<endl;
    int n;
    cin>>n;
    item arr[n];
    cout<<"Enter arrival time and burst time of each process:"<<endl;
    for(int i=0;i<n;i++){
        arr[i].pid=i+1;
        cin>>arr[i].stime;
        cin>>arr[i].btime;
    }
    sort(arr,arr+n,cmp);
    int start=INT_MAX;
    for(int i=0;i<n;i++){
        start=min(start,arr[i].stime);
    }
    for(int i=0;i<n;i++){
        arr[i].ctime=arr[i].btime+start;
        start+=arr[i].btime;
        arr[i].tatime=arr[i].ctime-arr[i].stime;
        arr[i].wtime=arr[i].tatime-arr[i].btime;
    }
    for(int i=0;i<n;i++){
        cout<<arr[i].pid<<"   "<<arr[i].stime<<"    "<<arr[i].btime<<"     "<<arr[i].ctime<<"       "<<arr[i].tatime<<"         "<<arr[i].wtime<<"      "<<endl;
    }
}