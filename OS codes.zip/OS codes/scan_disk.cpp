#include<bits/stdc++.h>
using namespace std;
void right(int head,int disks[],int n,int start,int end,int i){
    int total=0;
    total=abs(end-head)+abs(end-disks[0]);
    cout<<"The order of the disks is as following: "<<endl;
    
    if(disks[i-1]!=head){
        for(int j=i;j<n;j++){
        cout<<disks[j]<<" ";
    }
    for(int j=i-1;j>=0;j--){
        cout<<disks[j]<<" ";
    }
    }else{
        for(int j=i-1;j<n;j++){
        cout<<disks[j]<<" ";
    }
    for(int j=i-2;j>=0;j--){
        cout<<disks[j]<<" ";
    }
    }
    cout<<endl;
    cout<<total<<endl;
}
void left(int head,int disks[],int n,int start,int end,int i){
    int total=0;
    total=abs(start-head)+abs(start-disks[n-1]);
    cout<<"The order of the disks is as following: "<<endl;
    
    if(disks[i-1]!=head){
        for(int j=i-1;j>=0;j--){
        cout<<disks[j]<<" ";
    }
        for(int j=i;j<n;j++){
        cout<<disks[j]<<" ";
    }
    
    }else{
        for(int j=i-1;j>=0;j--){
        cout<<disks[j]<<" ";
    }
        for(int j=i;j<n;j++){
        cout<<disks[j]<<" ";
    }
    
    }
    cout<<endl;
    cout<<total<<endl;
}
int main(){
    int n;
    cout<<"Enter total no of tracks:"<<endl;
    cin>>n;
    cout<<"Enter the track numbers:"<<endl;
    int disks[n];
    for(int i=0;i<n;i++){
        cin>>disks[i];
    }
    int start,end;
    cout<<"Enter start:"<<endl;
    cin>>start;
    cout<<"Enter end:"<<endl;
    cin>>end;
    cout<<"Enter head:"<<endl;
    int head;
    cin>>head;
    int time=0;
    int curr=head,i=0;
    sort(disks,disks+n);
    for(i=0;i<n;i++){
        if(disks[i]>head) break;
    }
    char c;
    cout<<"Enter 'r' for right and 'l' for left:"<<endl;
    cin>>c;
    if(c=='r'){
        right(head,disks,n,start,end,i);
    }
    else if(c=='l'){
        left(head,disks,n,start,end,i);
    }
    
}