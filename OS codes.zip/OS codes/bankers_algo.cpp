#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,resources;
    cout<<"Enter no of process:"<<endl;
    cin>>n;
    cout<<"Enter no of resources:"<<endl;
    cin>>resources;
    int allocated[n][resources],maximum[n][resources],need[n][resources],available[0][resources];
    cout<<"Enter the allocated matrix:"<<endl;
    for(int i=0;i<n;i++){
        for(int j=0;j<resources;j++){
            cin>>allocated[i][j];
        }
    }
    cout<<"Enter the maximum matrix:"<<endl;
    for(int i=0;i<n;i++){
        for(int j=0;j<resources;j++){
            cin>>maximum[i][j];
        }
    }
    cout<<"Enter the available instances of resources:"<<endl;
    for(int j=0;j<resources;j++){
        cin>>available[0][j];
    }
    //if avaialble is not given then add all the allocated resources and subtract with the total resources which are given from user
    for(int i=0;i<n;i++){
        for(int j=0;j<resources;j++){
            need[i][j]=maximum[i][j]-allocated[i][j];
        }
    }
    cout<<"The process sequence is as follows:"<<endl;
    int visited[n];
    int i=0,c=0;
    while(c!=n){
        int count=0;
        if(visited[i]!=1){
            for(int j=0;j<resources;j++){
            if(need[i][j]<=available[0][j]){
                count++;
            }
        }
        if(count==resources&&visited[i]!=1){
            cout<<i<<" ";
            visited[i]=1;
            for(int j=0;j<resources;j++){
                available[0][j]+=allocated[i][j];
            }
            c++;
        }
        }
        i++;
        if(i==n){
            i=0;
        }
    }
}