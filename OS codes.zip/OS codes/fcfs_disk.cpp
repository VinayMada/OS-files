#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cout<<"Enter total no of tracks:"<<endl;
    cin>>n;
    cout<<"Enter the track numbers:"<<endl;
    int disks[n];
    for(int i=0;i<n;i++){
        cin>>disks[i];
    }
    int start,end;
    cout<<"Enter start:"<<endl;
    cin>>start;
    cout<<"Enter end:"<<endl;
    cin>>end;
    cout<<"Enter head:"<<endl;
    int head;
    cin>>head;
    int time=0,total=0;
    int curr=head;
    for(int i=0;i<n;i++){
        total+=abs(curr-disks[i]);
        curr=disks[i];
    }
    cout<<total<<endl;
}