#include<bits/stdc++.h>
using namespace std;
struct item{
    int pid;
    int stime;
    int btime;
    int ctime;
    int tatime;
    int wtime;
};
int visited[100]={0};
int findmin(int start,item arr[],int n){
    int index=-1,mini=INT_MAX;
    for(int i=0;i<n;i++){
        if(!visited[i]&&arr[i].stime<=start&&mini>arr[i].btime){
            mini=arr[i].btime;
            index=i;
        }
    }
    return index;
}
int main(){
    int n;
    cout<<"Enter no of process:"<<endl;
    cin>>n;
    item arr[n];
    cout<<"Enter arrival time and burst time of each process:"<<endl;
    for(int i=0;i<n;i++){
        arr[i].pid=i+1;
        cin>>arr[i].stime;
        cin>>arr[i].btime;
    }
    int start=INT_MAX;
    for(int i=0;i<n;i++){
        start=min(start,arr[i].stime);
    }
    int comptime=0;
    int count=0;
    while(count++<n){
        int i=findmin(start,arr,n);
        visited[i]=1;
        start+=arr[i].btime;
        arr[i].ctime=start;
        arr[i].tatime=arr[i].ctime-arr[i].stime;
        arr[i].wtime=arr[i].tatime-arr[i].btime;
    }
    cout<<"process_id"<<"   "<<"arrival_time"<<"    "<<"burst_time"<<"  "<<"completion_time"<<"     "<<"tat_time"<<"    "<<"waiting time"<<endl;
    for(int i=0;i<n;i++){
        cout<<arr[i].pid<<"             "<<arr[i].stime<<"                  "<<arr[i].btime<<"                  "<<arr[i].ctime<<"           "<<arr[i].tatime<<"                  "<<arr[i].wtime<<endl;
    }
}