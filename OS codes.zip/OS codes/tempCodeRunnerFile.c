#include<stdio.h>
#include<pthread.h>
void *yourtrun(void *arg)
{
    while(1)
    {
        printf("your turn\n");
    }
    return NULL;
}
void myturn()
{
    while(1)
    {
        sleep(2);
        printf("my turn\n");
    }
}
void main()
{
    pthread_t newthread;

    pthread_create(&newthread,NULL,yourtrun,NULL);
    //yourtrun();
    myturn();
}