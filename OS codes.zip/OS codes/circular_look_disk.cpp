#include<bits/stdc++.h>
using namespace std;
void left(int head,int disks[],int n,int start,int end,int i){
    int total=0;
    total=(abs(disks[0]-head))+abs(disks[0]-end);
    cout<<"The order of the disks is as following: "<<endl;
    
    if(disks[i-1]!=head){
        total+=abs(end-disks[i]);
        for(int j=i-1;j>=0;j--){
        cout<<disks[j]<<" ";
    }
    for(int j=n-1;j>=i;j--){
        cout<<disks[j]<<" ";
    }
    }else{
        total+=(abs(end-disks[i]));
        for(int j=i-1;j>=0;j--){
        cout<<disks[j]<<" ";
    }
    for(int j=n-1;j>=i;j--){
        cout<<disks[j]<<" ";
    }
    }
    cout<<endl;
    cout<<total<<endl;
}
void right(int head,int disks[],int n,int start,int end,int i){
    int total=0;
    total=(abs(disks[n-1]-head))+(disks[n-1]-start);
    cout<<"The order of the disks is as following: "<<endl;
    
    if(disks[i-1]!=head){
        total+=abs(disks[i-1]-start);
        for(int j=i;j<n;j++){
        cout<<disks[j]<<" ";
    }
    for(int j=0;j<=i-1;j++){
        cout<<disks[j]<<" ";
    }
    }else{
        total+=(abs(disks[i-2]-start));
        for(int j=i-1;j<n;j++){
        cout<<disks[j]<<" ";
    }
    for(int j=0;j<=i-2;j++){
        cout<<disks[j]<<" ";
    }
    }
    cout<<endl;
    cout<<total<<endl;
}
int main(){
    int n;
    cout<<"Enter total no of tracks:"<<endl;
    cin>>n;
    cout<<"Enter the track numbers:"<<endl;
    int disks[n];
    for(int i=0;i<n;i++){
        cin>>disks[i];
    }
    int start,end;
    cout<<"Enter start:"<<endl;
    cin>>start;
    cout<<"Enter end:"<<endl;
    cin>>end;
    cout<<"Enter head:"<<endl;
    int head;
    cin>>head;
    int time=0,total=0;
    int curr=head,i=0;
    sort(disks,disks+n);
    for(i=0;i<n;i++){
        if(disks[i]>head) break;
    }
    char c;
    cout<<"Enter 'r' for right and 'l' for left:"<<endl;
    cin>>c;
    if(c=='r')
    {
        right(head,disks,n,start,end,i);
    }
    else 
    left(head,disks,n,start,end,i);
}