#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cout<<"Enter no of pages:"<<endl;
    cin>>n;
    int pages[n];
    cout<<"Enter sizes of pages:"<<endl;
    for(int i=0;i<n;i++){
        cin>>pages[i];
    }
    int blocks;
    cout<<"Enter no of blocks:"<<endl;
    cin>>blocks;
    int blocks_sizes[blocks];
    cout<<"Enter sizes of blocks:"<<endl;
    for(int i=0;i<blocks;i++){
        cin>>blocks_sizes[i];
    }
    int visited[blocks];
    for(int i=0;i<n;i++){
        int index=-1,maxi=INT_MIN,j;
        for(j=0;j<blocks;j++){
            if(blocks_sizes[j]>=pages[i]&&visited[j]!=1&&maxi<(blocks_sizes[j]-pages[i])){
                maxi=blocks_sizes[j]-pages[i];
                index=j;
            }
        }
        if(index!=-1){
            cout<<"page "<<i+1<<" is allocated in frame"<<index+1<<endl;
            blocks_sizes[index]-=pages[i];
            visited[index]=1;
            continue;
        }
        if(j==blocks){
            int sum=0;
            bool flag=false;
            for(j=0;j<blocks;j++){
                sum+=blocks_sizes[j];
                if(blocks_sizes[j]>=pages[i]){
                    flag=true;
                    cout<<"page "<<i+1<<" undergoes internal fragmentation"<<endl;
                }
            }
            if(j==blocks&&sum>=pages[i]&&flag==false){
                cout<<"page "<<i+1<<" undergoes external fragmentation"<<endl;
            }
        }
    }
}